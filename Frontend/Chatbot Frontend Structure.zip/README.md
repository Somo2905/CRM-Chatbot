
  # Chatbot Frontend Structure

  This is a code bundle for Chatbot Frontend Structure. The original project is available at https://www.figma.com/design/VkUXx0VVxhTq0FjU1p3Htv/Chatbot-Frontend-Structure.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  