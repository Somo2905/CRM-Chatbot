import React from 'react';
import { ChatbotContainer } from './components/ChatbotContainer';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <ChatbotContainer />
    </div>
  );
}
